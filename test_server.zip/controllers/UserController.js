const UserService = require('../tests/services/UserService');

// La fonction permet d'ajouter un utilisateur
module.exports.addOneUser = function(req, res) {

}

// La fonction permet d'ajouter plusieurs utilisateurs
module.exports.addManyUsers = function(req, res) {

}

// La fonction permet de chercher un utilisateur
module.exports.findOneUser = function(req, res) {
    var user = _.find(UserSchema.elements, ["id", id])
    console.log(user)
    if (user) {
        callback(null, user)
    }
    else {
        callback({error: true,msg: 'Utilisateur not found.', error_type: 'Not-Found'})
    }
}

// La fonction permet de chercher plusieurs utilisateurs
module.exports.findManyUsers = function(req, res) {
    var users = _.filter(UserSchema.elements, (e) => { 
        return ids.indexOf(e.id) > -1
        })
        callback(null, users)
}

// La fonction permet de supprimer un utilisateur
module.exports.deleteOneUser = function(req, res) {
    
}

// La fonction permet de supprimer plusieurs utilisateurs
module.exports.deleteManyUsers = function(req, res) {
    
}

// La fonction permet de mettre à jour un utilisateur
module.exports.updateOneUser = function(req, res) {
        
}

// La fonction permet de mettre à jour plusieurs utilisateurs
module.exports.updateManyUsers = function(req, res) {
        
}