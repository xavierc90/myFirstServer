/* Connexionn à la base de données */
require('../utils/database')

describe("UserService", () => {
    require('./services/UserService.test')
})