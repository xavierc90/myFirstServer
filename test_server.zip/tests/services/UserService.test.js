const UserService = require('../../services/UserService')
const chai = require('chai');
let expect = chai.expect;

describe("addOneUser", () => {
    it("Utilisateur correct. - S", () => {
        var user = {
            firstName: "Edouard",
            lastName: "Dupont",
            email: "edouard.dupont@gmail.com",
            username: "edupont"
        }
        UserService.addOneUser(user, function (err, value) {
            expect(value).to.be.a('object');
            expect(value).to.haveOwnProperty('_id')
        }) 
    })
    it("Utilisateur incorrect. (Sans firstName) - E", () => {
        var user_no_valid = {
            lastName: "Dupont",
            email: "edouard.dupont@gmail.com",
            username: "edupont"
        }
        UserService.addOneUser(user_no_valid, function (err, value) {
            expect(err).to.haveOwnProperty('msg')
            expect(err).to.haveOwnProperty('fields_with_error').with.lengthOf(1)
            expect(err).to.haveOwnProperty('fields')
            expect(err['fields']).to.haveOwnProperty('firstName')
            expect(err['fields']['firstName']).to.equal('Path `firstName` is required.')
        }) 
    })
})

describe("addManyUsers", () => {
    it("Ajout de plusieurs utilisateurs non valides. - E", () => {
        var users_tab_error = [{
            firstName: "Edouard",
            lastName: "Dupont",
            email: "edouard.dupont@gmail.com",
            username: "edupont"
        },{
            firstName: "Edouard",
            lastName: "Dupont",
            email: "edouard.dupont@gmail.com",
            username: "",
            testing: true,
            phone: "0645102340"
        },{
            firstName: "Edouard",
            lastName: "Dupont",
            email: "edouard.dupont@gmail.com",
            username: "edupont",
            testing: true,
            phone: "0645102340"
        },{
            firstName: "Edouard",
            lastName: "Dupont",
            email: "edouard.dupont@gmail.com"
        }]

    })

    it("Utilisateurs à ajouter, valide. - S", () => {
        var users_tab_error = [{
            firstName: "Louison",
            lastName: "Dupont",
            email: "edouard.dupont@gmail.com",
            username: "edupont"
        }, {
            firstName: "Jordan",
            lastName: "Dupont",
            email: "edouard.dupont@gmail.com",
            username: "La",
            testing: true,
            phone: "0645102340"
        },
        {
            firstName: "Mathis",
            lastName: "Dupont",
            email: "edouard.dupont@gmail.com",
            username: "edupont",
            testing: true,
            phone: "0645102340"
        }]
        UserService.addManyUsers(users_tab_error, function(err, value) {
           console.log(err, value)
        })
    })

})

// describe("UserService", () => {
//     describe("addOneUser", () => {
//         it("Utilisateur valide. - S", () => {
//             var user_valid = {
//                 firstName: "Edouard",
//                 lastName: "Dupont",
//                 email: "edouard.dupont@gmail.com",
//                 username: "edupont"
//             }
//             UserService.addOneUser(user_valid, function (err, value) {
//                 expect(value).to.be.a('object');
//                 expect(value).to.haveOwnProperty('id')
//             })
//         })
//         it("Sans nom d'utilisateur. - E", () => {
//             var user_without_username = {
//                 firstName: "Edouard",
//                 lastName: "Dupont",
//                 email: "edouard.dupont@gmail.com"
//             }
//             UserService.addOneUser(user_without_username, function (err, value) {
//                 expect(err).to.haveOwnProperty('msg')
//                 expect(err).to.haveOwnProperty('key_required_not_include').with.lengthOf(1)

//             })
//         })

//         it("Avec un champs en trop. - S", () => {
//             var user_with_not_authorized_key = {
//                 firstName: "Edouard",
//                 lastName: "Dupont",
//                 email: "edouard.dupont@gmail.com",
//                 username: "edupont",
//                 testing: true,
//                 phone: "0645102340"
//             }
//              UserService.addOneUser(user_with_not_authorized_key, function(err, value) {
//                 expect(value).to.be.a('object');
//                 expect(value).to.haveOwnProperty('id')
//                 expect(value).not.haveOwnProperty('testing')
//             })
//         })

//         it("Avec un champs requis vide. - E", () => {
//             var user_with_not_authorized_key = {
//                 firstName: "Edouard",
//                 lastName: "Dupont",
//                 email: "edouard.dupont@gmail.com",
//                 username: "",
//                 testing: true,
//                 phone: "0645102340"
//             }
//             UserService.addOneUser(user_with_not_authorized_key, function(err, value) {
//                 expect(err).to.haveOwnProperty('msg')
//                 expect(err).to.haveOwnProperty('key_required_empty').with.lengthOf(1)

//             }) 
//         })
        
//     })
//     describe("updateOneUser", () => {
//         it("Modification d'un utilisateur correct. - S",() => {
//             UserService.updateOneUser('1', {lastName: "Maurice"},function(err, value) {
//                 expect(value).to.be.a('object');
//                 expect(value).to.haveOwnProperty('lastName')
//                 expect(value.lastName).to.equal("Maurice")
//             }) 
//         })
//         it("Modification d'un utilisateur avec un champs vide requis. - E",() => {
//             UserService.updateOneUser('1', {lastName: ""},function(err, value) {
//                 expect(err).to.haveOwnProperty('msg')
//                 expect(err).to.haveOwnProperty('key_required_empty').with.lengthOf(1, "Le tableau n'a pas retourné le nombre correcte d'éléments empty")
//             })
//         })
//         it("Modification d'un utilisateur avec un id non valide. -E", () => {
//             UserService.updateOneUser('100', {lastName: "Edouard"},function(err, value) {
//                 expect(err).to.haveOwnProperty('msg')
//                 expect(err).to.haveOwnProperty('key_required_empty').with.lengthOf(0)
//                 expect(err).to.haveOwnProperty('key_required_not_include').with.lengthOf(0)
//             })
//         })
//     })
//     describe("addManyUser", () => {
//         it("Ajout de plusieurs utilisateurs non corrects - E", () => {
//             var users_tab_error = [{
//                 firstName: "Edouard",
//                 lastName: "Dupont",
//                 email: "edouard.dupont@gmail.com",
//                 username: "edupont"
//             },{
//                 firstName: "Edouard",
//                 lastName: "Dupont",
//                 email: "edouard.dupont@gmail.com",
//                 username: "",
//                 testing: true,
//                 phone: "0645102340"
//             },
//             {
//                 firstName: "Edouard",
//                 lastName: "Dupont",
//                 email: "edouard.dupont@gmail.com",
//                 username: "edupont",
//                 testing: true,
//                 phone: "0645102340"
//             },{
//                 firstName: "Edouard",
//                 lastName: "Dupont",
//                 email: "edouard.dupont@gmail.com"
//             }] 
//             UserService.addManyUsers(users_tab_error,function(err, value) {
//                 expect(err).to.have.lengthOf(2)
//                 expect(err[0]).to.haveOwnProperty('msg')
//                 expect(err[0]).to.haveOwnProperty('key_required_empty').with.lengthOf(1)
//                 expect(err[1]).to.haveOwnProperty('msg')
//                 expect(err[1]).to.haveOwnProperty('key_required_empty').with.lengthOf(0)
//                 expect(err[1]).to.haveOwnProperty('key_required_not_include').with.lengthOf(1)
//             })          
//         })
//         it("Ajout de plusieurs utilisateurs corrects - S", () => {
//             var users_tab_error = [{
//                 firstName: "Edouard",
//                 lastName: "Dupont",
//                 email: "edouard.dupont@gmail.com",
//                 username: "edupont"
//             },{
//                 firstName: "Edouard",
//                 lastName: "Dupont",
//                 email: "edouard.dupont@gmail.com",
//                 username: "La",
//                 testing: true,
//                 phone: "0645102340"
//             },
//             {
//                 firstName: "Edouard",
//                 lastName: "Dupont",
//                 email: "edouard.dupont@gmail.com",
//                 username: "edupont",
//                 testing: true,
//                 phone: "0645102340"
//             }]
//             UserService.addManyUsers(users_tab_error,function(err, value) {
//             expect(value).to.have.lengthOf(users_tab_error.length);
//             value.forEach((e) => {
//             expect(e).to.be.a('object')
//             expect(e).to.haveOwnProperty('id')
//             expect(e).to.haveOwnProperty('lastName')
//             });
//             })           
//         })
//     })

//     describe("findOneUser", () => {
//         it("Rechercher un utilisateur existant correct - S", () => {
//             // A COMPLETER
//         })
//         it("Rechercher un utilisateur existant correct - S", () => {
//             // A COMPLETER
//         })
//     })
//     describe("findManyUsers", () => {
//         it("Chercher plusieurs utilisateurs existants. -S", () => {
//             // A COMPLETER
//         })
//         it("Chercher plusieurs utilisateurs qui n'existent pas. -E", () => {
//             // A COMPLETER
//         })
//     })
//     describe("deleteOneUser", () => {
//         it("Supprimer un utilisateur qui existe", () => {
//             // A COMPLETER
//         })
//         it("Supprimer un utilisateur qui n'existe pas", () => {
//             // A COMPLETER
//         })
//     })
//     describe("deleteManyUsers", () => {
//         it("Supprimer plusieurs utilisateurs existants. -S", () => {
//             // A COMPLETER
//         })
//         it("Supprimer plusieurs utilisateurs qui n'existent pas. -E", () => {
//             // A COMPLETER
//         })
//     })
// }) 
// /* 



// UserService.updateOneUser('1', {lastName: "Maurice"},function(err, value) {
//     if (err)
//         console.log("Une erreur s'est produite.", err.msg)
//     else {
//         console.log(value)
//     }
// }) 

// UserService.updateOneUser('1', {lastName: ""},function(err, value) {
//     if (err)
//         console.log("Une erreur s'est produite.", err.msg)
//     else {
//         console.log(value)
//     }
// }) 


// var users_tab_error = [{
//     firstName: "Edouard",
//     lastName: "Dupont",
//     email: "edouard.dupont@gmail.com",
//     username: "edupont"
// },{
//     firstName: "Edouard",
//     lastName: "Dupont",
//     email: "edouard.dupont@gmail.com",
//     username: "",
//     testing: true,
//     phone: "0645102340"
// },
// {
//     firstName: "Edouard",
//     lastName: "Dupont",
//     email: "edouard.dupont@gmail.com",
//     username: "edupont",
//     testing: true,
//     phone: "0645102340"
// },{
//     firstName: "Edouard",
//     lastName: "Dupont",
//     email: "edouard.dupont@gmail.com"
// }]

// console.log("ADD MANY")
// UserService.addManyUsers(users_tab_error,function(err, value) {
//     if (err)
//         console.log("Une erreur s'est produite.", err.msg)
//     else {
//         console.log(value)
//     }
// }) 


// var users_tab_error = [{
//     firstName: "Edouard",
//     lastName: "Dupont",
//     email: "edouard.dupont@gmail.com",
//     username: "edupont"
// },{
//     firstName: "Edouard",
//     lastName: "Dupont",
//     email: "edouard.dupont@gmail.com",
//     username: "La",
//     testing: true,
//     phone: "0645102340"
// },
// {
//     firstName: "Edouard",
//     lastName: "Dupont",
//     email: "edouard.dupont@gmail.com",
//     username: "edupont",
//     testing: true,
//     phone: "0645102340"
// }]

// console.log("ADD MANY")
// UserService.addManyUsers(users_tab_error,function(err, value) {
//     if (err)
//         console.log("Une erreur s'est produite.", err.msg)
//     else {
//         console.log(value)
//     }
// }) 

// console.log("CHERCHER PLUSIEURS UTILISATEURS")
// var tabIds = ["100", "200"]
// UserService.findManyUsers(tabIds, function(err, value) {
//     console.log(value)
// }) */